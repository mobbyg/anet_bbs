ANet ZModem test packet
==============================

This zip file is a test of the Zmodem download for ANet BBS. The complete system has yet to be implemented, 
but on a basic level, this will allow us to test how the download procedure is working. If you are able to open the files in this 
zip archive, then it has been a successful test. 

Directory handling and FILE_ID.DIZ will be added in the future.

Thanks!

-MobbyG
